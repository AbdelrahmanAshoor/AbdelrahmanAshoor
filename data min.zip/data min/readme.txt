//add names
The code begins by defining functions, and importing libraries

1-drop_collinear(df, cutoff_rate):
	this function is reponsible for dropping collinear columns, collinear columns can cause problems because both columns give 
	the same information, so when they are both used the model starts fitting to the random variance within the data.

	it works by measuring the correlation between columns, and if two of them are correlated beyond a certain threshold(cutoff_rate),
	one of them is removed.

2-stratified_sampling(df):
	this function is responsible for ensuring that the sample is perfectly representative for the population it is drawn from, by
	dividing the population into strata then ensuring that every stratum is represented in the sample.
	
	this is useful to ensure that the measure for model accuracy is precise, and that the model will work on all classes of data.

3-decimal_scaler(df, columns):
	this function is does normalizing by decimal scaling for the data by getting the maximum power of 10, and divide the data by it.

pandas and numpy -> important for basic statistical functions, data analysis functions and dataframe representation
plotly, matplotlib and seaborn -> used for plotting and visualization
sklearn -> a library used for machine learning functions which will be explained later

in the first section, we import and inspect the data to look for null values and understand its structure, the info() and head() functions can
be used for this purpose

the describe() function produces summary statistics for each column, a 5-number summary, mean and standard deviation
//============================================================================================================================================//
Data cleaning:
No null values were observed.
We first make box-plots to identify distributions and outliers, to improve the accuracy of our models.
the outliers are defined as points further than three standard eviations from the mean of the data, or around 1.5 * the interquartile range.
the outliers(df_out) function dpes this, decides the interquartile range and loops over points checking for outliers, and removes if they are
outside the range.
further cleaning and preprocessing will be conducting depending on the needs of each model, such as normalization and dropping collinear variables.
//============================================================================================================================================//
Exploratory analysis:
We find the correlation matrix using corr(), and plot using seaborn heatmaps
using the libraries seaborn and plotly for charts and visualizations
We use the countplot to plot the count of categorical variables with each class
//============================================================================================================================================//
Machine learning:
the make_pipeline function is used to construct a pipeline, which is a set of routines applied one after another to obtain data obeying
specific constraints.
MinMaxScalar is used to make all the values between 0 and 1 bysubtracting the minimum and dividing by their new maximum
OneHotEncoder transforms categorical variables into a set of binary columns, following one hot encoding 
The ConfusionMatrix() function calculates the confusion matrix for our classifier
SVM, and MultinomialNB fit support vector machines and naive bayes models, respectively. MultinomialNB is chosen because it is most fitting 
due to most variables being discrete 